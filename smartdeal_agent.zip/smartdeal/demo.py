#!/usr/bin/env python3
"""
SmartDeal Demo — Automated negotiation scenarios (no user input needed).
Shows the agent's behavior in 3 different scenarios.
"""

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from core.product import get_product_by_id
from core.negotiation_engine import NegotiationEngine

SEP = "─" * 65


def run_scenario(title: str, product_id: str, offers: list[float], buyer_profile: str = "new"):
    product = get_product_by_id(product_id)
    engine = NegotiationEngine(product, buyer_profile=buyer_profile)

    print(f"\n{SEP}")
    print(f"  SCENARIO: {title}")
    print(f"  Product:  {product.name}  |  List: ${product.list_price:.2f}")
    print(f"  Buyer:    {buyer_profile}  |  Agent Style: {engine.strategy.get_style_label()}")
    print(SEP)

    opening = engine.open_negotiation()
    print(f"\n[Alex]: {opening}\n")

    for offer in offers:
        print(f"[Buyer]: ${offer:.2f}")
        response, deal_closed, walked_away = engine.receive_offer(offer)
        print(f"[Alex]:  {response}\n")
        if deal_closed or walked_away:
            break

    summary = engine.get_session_summary()
    print(f"\n── Summary ──")
    if summary["deal_closed"]:
        print(f"  ✅ DEAL at ${summary['deal_price']:.2f}  |  Saved ${summary['savings']:.2f} ({summary['savings_pct']}%)  |  {summary['rounds']} rounds")
    else:
        print(f"  ❌ No deal after {summary['rounds']} rounds")
    print()


if __name__ == "__main__":
    print("\n" + "=" * 65)
    print("  SmartDeal AI Negotiation Engine — Demo Scenarios")
    print("=" * 65)

    # Scenario 1: Savvy buyer negotiates a laptop step by step
    run_scenario(
        title="Smart Negotiator — Laptop (step-by-step)",
        product_id="LP001",
        offers=[900, 950, 980, 1010, 1040],
        buyer_profile="loyal",
    )

    # Scenario 2: Insulting low-ball attempt on headphones
    run_scenario(
        title="Low-Ball Attempt — Headphones",
        product_id="HD003",
        offers=[50, 100],
        buyer_profile="new",
    )

    # Scenario 3: VIP buyer, motivated seller, quick deal
    run_scenario(
        title="VIP Quick Deal — Standing Desk",
        product_id="WC004",
        offers=[420, 440],
        buyer_profile="vip",
    )

    # Scenario 4: Stubborn buyer never improves — agent walks
    run_scenario(
        title="Stalled Negotiation — Webcam",
        product_id="CM005",
        offers=[100, 100, 100, 100, 100],
        buyer_profile="new",
    )

    print("=" * 65)
    print("  End of Demo — Run `python main.py` for interactive mode!")
    print("=" * 65 + "\n")
