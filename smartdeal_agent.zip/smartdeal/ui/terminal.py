"""
SmartDeal Terminal UI — Rich-powered interactive interface.
"""

import sys
import time
import textwrap
from typing import Optional

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.prompt import Prompt, Confirm
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.text import Text
    from rich.columns import Columns
    from rich.rule import Rule
    from rich import box
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

import sys
sys.path.insert(0, str(__import__('pathlib').Path(__file__).parent.parent))

from core.product import CATALOG, Product, get_product_by_id
from core.negotiation_engine import NegotiationEngine
from core.pricing_strategy import NegotiationStyle

console = Console() if HAS_RICH else None

# ─── Colors / Styles ────────────────────────────────────────────────────────
BRAND_COLOR = "cyan"
AGENT_COLOR = "green"
BUYER_COLOR = "yellow"
DEAL_COLOR = "bold green"
WARN_COLOR = "red"


def _print(text: str, style: str = ""):
    if HAS_RICH:
        console.print(text, style=style)
    else:
        print(text)


def _rule(title: str = ""):
    if HAS_RICH:
        console.rule(f"[{BRAND_COLOR}]{title}[/]")
    else:
        print(f"\n{'─'*50} {title} {'─'*50}\n")


def _agent_say(text: str):
    """Print agent dialogue with styled panel."""
    if HAS_RICH:
        wrapped = textwrap.fill(text, width=72)
        console.print(Panel(
            f"[{AGENT_COLOR}]{wrapped}[/]",
            title=f"[bold {AGENT_COLOR}]🤖 Alex (SmartDeal Agent)[/]",
            border_style=AGENT_COLOR,
            padding=(0, 2),
        ))
    else:
        print(f"\n[Alex]: {text}\n")


def _buyer_say(text: str):
    if HAS_RICH:
        console.print(f"[{BUYER_COLOR}]You:[/] {text}")
    else:
        print(f"You: {text}")


def _thinking_pause(msg: str = "Alex is considering your offer..."):
    if HAS_RICH:
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[{AGENT_COLOR}]{msg}[/]"),
            transient=True,
            console=console,
        ) as progress:
            progress.add_task("", total=None)
            time.sleep(1.2)
    else:
        print(f"\n{msg}")
        time.sleep(0.8)


# ─── Catalog Browser ────────────────────────────────────────────────────────

def show_catalog():
    _rule("🛍️  SmartDeal Product Catalog")

    if HAS_RICH:
        table = Table(
            show_header=True,
            header_style=f"bold {BRAND_COLOR}",
            box=box.ROUNDED,
            expand=True,
        )
        table.add_column("#", style="dim", width=5)
        table.add_column("ID", style=BRAND_COLOR, width=7)
        table.add_column("Product", min_width=24)
        table.add_column("Category", width=14)
        table.add_column("List Price", justify="right", width=11)
        table.add_column("Stock", justify="center", width=7)
        table.add_column("Status", width=18)

        for i, p in enumerate(CATALOG, 1):
            price_str = f"${p.list_price:,.2f}"
            stock_str = str(p.stock)

            if p.stock <= 1:
                stock_style = "bold red"
                status = "🔥 Last unit!"
            elif p.stock <= 3:
                stock_style = "red"
                status = f"⚡ Only {p.stock} left"
            else:
                stock_style = "white"
                status = "✅ In stock"

            if p.demand_score >= 0.8:
                status += " 📈"

            table.add_row(
                str(i),
                p.id,
                f"[bold]{p.name}[/]",
                p.category,
                f"[bold]{price_str}[/]",
                f"[{stock_style}]{stock_str}[/]",
                status,
            )

        console.print(table)
    else:
        print(f"\n{'ID':<8} {'Product':<30} {'Price':>10} {'Stock':>6}")
        print("-" * 60)
        for p in CATALOG:
            print(f"{p.id:<8} {p.name:<30} ${p.list_price:>9.2f} {p.stock:>6}")
    print()


def show_product_detail(product: Product):
    _rule(f"📦 {product.name}")
    if HAS_RICH:
        info = (
            f"[bold]Category:[/] {product.category}\n"
            f"[bold]List Price:[/] [bold {BRAND_COLOR}]${product.list_price:,.2f}[/]\n"
            f"[bold]Stock:[/] {product.stock} units\n"
            f"[bold]Demand:[/] {'█' * int(product.demand_score * 10)}{'░' * (10 - int(product.demand_score * 10))} {int(product.demand_score*100)}%\n\n"
            f"[dim]{product.description}[/]"
        )
        if product.urgency_hint:
            info += f"\n\n[bold red]⚠️  {product.urgency_hint}[/]"
        console.print(Panel(info, border_style=BRAND_COLOR, padding=(1, 2)))
    else:
        print(f"\n{product.name}")
        print(f"Price: ${product.list_price:.2f} | Stock: {product.stock}")
        print(f"Description: {product.description}")
        if product.urgency_hint:
            print(f"⚠️  {product.urgency_hint}")
    print()


# ─── Negotiation Session ─────────────────────────────────────────────────────

def run_negotiation(product: Product):
    buyer_profile = "new"

    if HAS_RICH:
        profile = Prompt.ask(
            f"\n[{BRAND_COLOR}]Your buyer profile[/]",
            choices=["new", "loyal", "vip"],
            default="new",
        )
        buyer_profile = profile

    engine = NegotiationEngine(product, buyer_profile=buyer_profile)

    _rule("💬 Negotiation Session")

    style_label = engine.strategy.get_style_label()
    _print(
        f"  Starting negotiation on: [bold]{product.name}[/]  |  "
        f"List: [bold {BRAND_COLOR}]${product.list_price:.2f}[/]  |  "
        f"Agent mode: [italic]{style_label}[/]",
        style=""
    )
    print()

    # Agent opens
    opening = engine.open_negotiation()
    _agent_say(opening)

    while True:
        print()

        if HAS_RICH:
            offer_str = Prompt.ask(f"[{BUYER_COLOR}]Your offer ($)[/] (or 'q' to quit)")
        else:
            offer_str = input("Your offer ($) or 'q' to quit: ").strip()

        if offer_str.lower() in ("q", "quit", "exit", "no"):
            _print("\n👋 You walked away from the negotiation.", style="dim")
            break

        # Parse offer
        try:
            offer = float(offer_str.replace("$", "").replace(",", "").strip())
            if offer <= 0:
                raise ValueError
        except ValueError:
            _print("⚠️  Please enter a valid dollar amount (e.g. 250 or 249.99)", style=WARN_COLOR)
            continue

        _buyer_say(f"${offer:,.2f}")
        _thinking_pause()

        response, deal_closed, walked_away = engine.receive_offer(offer)
        _agent_say(response)

        if deal_closed or walked_away:
            break

    # Session summary
    _show_summary(engine)


def _show_summary(engine: NegotiationEngine):
    summary = engine.get_session_summary()
    _rule("📊 Negotiation Summary")

    if HAS_RICH:
        if summary["deal_closed"]:
            panel_style = "bold green"
            header = "🎉 DEAL CLOSED!"
            body = (
                f"[bold]Product:[/] {summary['product']}\n"
                f"[bold]List Price:[/] ${summary['list_price']:,.2f}\n"
                f"[bold]Deal Price:[/] [bold green]${summary['deal_price']:,.2f}[/]\n"
                f"[bold]You saved:[/] [bold green]${summary['savings']:,.2f} ({summary['savings_pct']}%)[/]\n"
                f"[bold]Rounds:[/] {summary['rounds']}\n"
                f"[bold]Agent Style:[/] {summary['agent_style']}"
            )
            console.print(Panel(body, title=header, border_style="green", padding=(1, 2)))
        else:
            panel_style = "dim"
            header = "No Deal Reached"
            body = (
                f"[bold]Product:[/] {summary['product']}\n"
                f"[bold]List Price:[/] ${summary['list_price']:,.2f}\n"
                f"[bold]Rounds Negotiated:[/] {summary['rounds']}\n"
                f"[bold]Your Offers:[/] {', '.join(f'${o:.2f}' for o in summary['buyer_offers'])}\n"
                f"[bold]Agent Style:[/] {summary['agent_style']}"
            )
            console.print(Panel(body, title=header, border_style="dim", padding=(1, 2)))
    else:
        if summary["deal_closed"]:
            print(f"\n✅ DEAL! Paid: ${summary['deal_price']:.2f} | Saved: ${summary['savings']:.2f} ({summary['savings_pct']}%)")
        else:
            print(f"\nNo deal after {summary['rounds']} rounds.")


# ─── Main App Loop ───────────────────────────────────────────────────────────

def main():
    if HAS_RICH:
        console.clear()
        console.print(Panel.fit(
            "[bold cyan]SmartDeal[/] [white]— AI Price Negotiation Agent[/]\n"
            "[dim]Powered by an intelligent pricing strategy engine[/]",
            border_style="cyan",
            padding=(1, 4),
        ))
    else:
        print("\n" + "="*60)
        print("  SmartDeal — AI Price Negotiation Agent")
        print("="*60)

    while True:
        print()
        show_catalog()

        if HAS_RICH:
            choice = Prompt.ask(
                f"[{BRAND_COLOR}]Enter product ID to negotiate[/] (or 'q' to quit)",
                default="LP001",
            )
        else:
            choice = input("Enter product ID (or 'q' to quit): ").strip().upper()

        if choice.lower() in ("q", "quit", "exit"):
            _print("\n👋 Thanks for visiting SmartDeal! Come back anytime.", style=BRAND_COLOR)
            break

        product = get_product_by_id(choice.upper())
        if not product:
            _print(f"❌ Product '{choice}' not found. Try one from the catalog above.", style=WARN_COLOR)
            continue

        show_product_detail(product)

        if HAS_RICH:
            go = Confirm.ask(f"[{BRAND_COLOR}]Start negotiating for this product?[/]", default=True)
        else:
            go = input("Start negotiating? (y/n): ").strip().lower() == "y"

        if go:
            run_negotiation(product)

        print()
        if HAS_RICH:
            again = Confirm.ask(f"[{BRAND_COLOR}]Negotiate another product?[/]", default=True)
        else:
            again = input("Negotiate another product? (y/n): ").strip().lower() == "y"

        if not again:
            _print("\n👋 Thanks for using SmartDeal! Come back anytime.", style=BRAND_COLOR)
            break


if __name__ == "__main__":
    main()
