"""
Product catalog for SmartDeal AI Agent.
Each product has pricing bounds and negotiation metadata.
"""

from dataclasses import dataclass, field
from typing import Optional
import random


@dataclass
class Product:
    id: str
    name: str
    category: str
    list_price: float          # Displayed price
    floor_price: float         # Absolute minimum (never revealed)
    cost_price: float          # Internal cost (never revealed)
    stock: int                 # Units in stock
    description: str
    tags: list[str] = field(default_factory=list)
    demand_score: float = 0.5  # 0.0 (cold) to 1.0 (hot)

    @property
    def negotiation_room(self) -> float:
        """How much % the agent CAN discount from list price."""
        return ((self.list_price - self.floor_price) / self.list_price) * 100

    @property
    def is_low_stock(self) -> bool:
        return self.stock <= 3

    @property
    def urgency_hint(self) -> Optional[str]:
        if self.stock <= 1:
            return "Last one in stock!"
        if self.stock <= 3:
            return f"Only {self.stock} left!"
        if self.demand_score >= 0.85:
            return "High demand item!"
        return None

    def __str__(self):
        return f"{self.name} (${self.list_price:.2f})"


# ─── Product Catalog ────────────────────────────────────────────────────────

CATALOG: list[Product] = [
    Product(
        id="LP001",
        name='ProBook X15 Laptop',
        category='Electronics',
        list_price=1299.00,
        floor_price=999.00,
        cost_price=820.00,
        stock=5,
        description='15.6" 4K display, Intel i7, 16GB RAM, 512GB SSD. Perfect for professionals.',
        tags=['laptop', 'work', 'premium'],
        demand_score=0.78,
    ),
    Product(
        id="PH002",
        name='NovaSpark Pro Phone',
        category='Electronics',
        list_price=849.00,
        floor_price=699.00,
        cost_price=580.00,
        stock=12,
        description='6.7" AMOLED, 200MP camera, 5000mAh, 5G capable flagship smartphone.',
        tags=['phone', 'flagship', '5g'],
        demand_score=0.91,
    ),
    Product(
        id="HD003",
        name='SoundWave ANC Headphones',
        category='Audio',
        list_price=299.00,
        floor_price=219.00,
        cost_price=145.00,
        stock=2,
        description='40hr battery, industry-leading noise cancellation, premium audio quality.',
        tags=['headphones', 'anc', 'audio'],
        demand_score=0.82,
    ),
    Product(
        id="WC004",
        name='ErgoPro Standing Desk',
        category='Furniture',
        list_price=599.00,
        floor_price=429.00,
        cost_price=320.00,
        stock=8,
        description='Electric height-adjustable desk, 3 memory presets, 300lb capacity.',
        tags=['desk', 'ergonomic', 'office'],
        demand_score=0.55,
    ),
    Product(
        id="CM005",
        name='ZenFocus 4K Webcam',
        category='Electronics',
        list_price=189.00,
        floor_price=139.00,
        cost_price=88.00,
        stock=1,
        description='4K30fps, auto-framing AI, dual noise-cancelling mics, HDR support.',
        tags=['webcam', '4k', 'streaming'],
        demand_score=0.67,
    ),
    Product(
        id="KB006",
        name='MechKey Pro Keyboard',
        category='Peripherals',
        list_price=159.00,
        floor_price=119.00,
        cost_price=72.00,
        stock=15,
        description='Wireless mechanical keyboard, Cherry MX switches, RGB backlighting, 3-device.',
        tags=['keyboard', 'mechanical', 'wireless'],
        demand_score=0.44,
    ),
]


def get_product_by_id(product_id: str) -> Optional[Product]:
    return next((p for p in CATALOG if p.id == product_id), None)


def get_products_by_category(category: str) -> list[Product]:
    return [p for p in CATALOG if p.category.lower() == category.lower()]
