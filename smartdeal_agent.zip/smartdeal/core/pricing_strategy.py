"""
SmartDeal Pricing Strategy Engine.

The agent's "brain" for deciding when to accept, counter, or walk away.
Uses multi-factor scoring: offer distance, round fatigue, demand, stock urgency,
buyer sentiment, and negotiation style.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional
import math

from .product import Product


class NegotiationStyle(Enum):
    FIRM = "firm"           # High-demand / low-stock — minimal discounts
    FLEXIBLE = "flexible"   # Normal — standard negotiation
    EAGER = "eager"         # Low-demand / excess stock — wants to close fast


class AgentDecision(Enum):
    ACCEPT = "accept"
    COUNTER = "counter"
    WALK_AWAY = "walk_away"
    FINAL_OFFER = "final_offer"


@dataclass
class NegotiationContext:
    product: Product
    round_number: int = 0
    buyer_offer_history: list[float] = None
    buyer_sentiment: float = 0.5     # 0=hostile, 0.5=neutral, 1=friendly
    concession_fatigue: float = 0.0  # Increases as agent gives more discounts
    buyer_profile: str = "unknown"   # loyal / new / vip

    def __post_init__(self):
        if self.buyer_offer_history is None:
            self.buyer_offer_history = []

    @property
    def latest_offer(self) -> Optional[float]:
        return self.buyer_offer_history[-1] if self.buyer_offer_history else None

    @property
    def buyer_trend(self) -> str:
        """Is the buyer increasing their offers?"""
        if len(self.buyer_offer_history) < 2:
            return "unknown"
        delta = self.buyer_offer_history[-1] - self.buyer_offer_history[-2]
        if delta > 5:
            return "rising"
        elif delta < -5:
            return "falling"
        return "flat"

    @property
    def total_agent_discount_given(self) -> float:
        """How much has the agent dropped from list price so far."""
        return self.concession_fatigue * self.product.list_price


class PricingStrategy:
    """Determines agent's negotiation style and calculates counter-offers."""

    def __init__(self, product: Product):
        self.product = product
        self.style = self._determine_style()

    def _determine_style(self) -> NegotiationStyle:
        p = self.product
        if p.demand_score >= 0.8 or p.is_low_stock:
            return NegotiationStyle.FIRM
        elif p.demand_score <= 0.5 and p.stock > 8:
            return NegotiationStyle.EAGER
        return NegotiationStyle.FLEXIBLE

    def evaluate_offer(self, ctx: NegotiationContext) -> tuple[AgentDecision, float, str]:
        """
        Core decision function.
        Returns: (decision, agent_price, reasoning_note)
        """
        offer = ctx.latest_offer
        product = ctx.product
        round_num = ctx.round_number

        # Compute the floor with a small dynamic buffer
        dynamic_floor = product.floor_price * self._floor_multiplier(ctx)

        # If buyer is insulting low
        if offer < product.cost_price * 0.9:
            return (
                AgentDecision.WALK_AWAY,
                product.list_price,
                "offer_insultingly_low"
            )

        # If buyer is at or above floor — accept
        if offer >= dynamic_floor:
            return (AgentDecision.ACCEPT, offer, "offer_acceptable")

        # Calculate how much room is left to give
        remaining_gap = dynamic_floor - offer
        max_concession = product.list_price - dynamic_floor

        # Walk away if too many rounds without progress
        if round_num >= 5 and ctx.buyer_trend != "rising":
            return (AgentDecision.WALK_AWAY, dynamic_floor, "max_rounds_reached")

        # Final offer on round 4 if buyer trend stalled
        if round_num == 4:
            return (AgentDecision.FINAL_OFFER, dynamic_floor, "final_offer")

        # Compute counter-offer
        counter = self._calculate_counter(ctx, dynamic_floor)
        return (AgentDecision.COUNTER, counter, "counter_offer")

    def _floor_multiplier(self, ctx: NegotiationContext) -> float:
        """Adjusts effective floor based on context."""
        base = 1.0

        # Loyal/VIP buyers get a tiny edge
        if ctx.buyer_profile == "vip":
            base -= 0.015
        elif ctx.buyer_profile == "loyal":
            base -= 0.008

        # Eager style = more willing to go lower
        if self.style == NegotiationStyle.EAGER:
            base -= 0.02
        elif self.style == NegotiationStyle.FIRM:
            base += 0.03

        # If buyer is friendly, slight benefit
        if ctx.buyer_sentiment > 0.7:
            base -= 0.01

        return max(base, 0.92)  # Never drop multiplier below 92%

    def _calculate_counter(self, ctx: NegotiationContext, dynamic_floor: float) -> float:
        """
        Calculates the agent's counter-offer using a sigmoid concession curve.
        Early rounds: bigger drops. Late rounds: smaller steps (tightening).
        """
        offer = ctx.latest_offer
        list_price = ctx.product.list_price
        round_num = ctx.round_number

        # Current agent "position" — starts at list price
        current_agent_price = list_price - ctx.total_agent_discount_given

        # How eager is agent to close?
        eagerness = {
            NegotiationStyle.FIRM: 0.25,
            NegotiationStyle.FLEXIBLE: 0.45,
            NegotiationStyle.EAGER: 0.65,
        }[self.style]

        # Concession step: larger early, smaller later (sigmoid squeeze)
        round_factor = 1 / (1 + math.exp(round_num - 3))
        step = (current_agent_price - max(offer, dynamic_floor)) * eagerness * round_factor

        counter = current_agent_price - step
        counter = max(counter, dynamic_floor)
        counter = min(counter, list_price)

        # Round to nearest $0.50 for naturalness
        return round(counter * 2) / 2

    def get_style_label(self) -> str:
        return {
            NegotiationStyle.FIRM: "Firm Seller",
            NegotiationStyle.FLEXIBLE: "Flexible Seller",
            NegotiationStyle.EAGER: "Motivated Seller",
        }[self.style]
