"""
SmartDeal Negotiation Engine.

Generates human-like negotiation dialogue using LLM-style template reasoning.
The agent has a personality: professional, persuasive, and strategically warm.
Falls back to template responses if no API key — fully self-contained.
"""

import os
import random
import textwrap
from typing import Optional

from .product import Product
from .pricing_strategy import (
    AgentDecision, NegotiationContext, NegotiationStyle, PricingStrategy
)


# ─── Persona & Dialogue Templates ───────────────────────────────────────────

AGENT_NAME = "Alex"
AGENT_PERSONA = "a sharp, friendly SmartDeal sales agent who knows the market well"

OPENER_TEMPLATES = {
    NegotiationStyle.FIRM: [
        "I appreciate your interest in the {name}! It's one of our best-sellers right now. "
        "The listed price of ${list_price:.2f} reflects its premium quality — what did you have in mind?",
        "Great choice on the {name}! Honestly, at ${list_price:.2f}, this is already competitively priced. "
        "That said, I'm all ears — what's your offer?",
    ],
    NegotiationStyle.FLEXIBLE: [
        "Welcome! The {name} is an excellent pick at ${list_price:.2f}. "
        "I'm open to a conversation — what are you thinking?",
        "The {name} is a solid product and I'd love to help you bring it home. "
        "We're listed at ${list_price:.2f}. Let's see what we can work out!",
    ],
    NegotiationStyle.EAGER: [
        "Hey, glad you're looking at the {name}! We've got good stock and I want to move it. "
        "Listed at ${list_price:.2f} — but I'm definitely open to talking numbers.",
        "The {name} is a fantastic deal at ${list_price:.2f}. Between us, "
        "I have some flexibility today. What's your best offer?",
    ],
}

COUNTER_TEMPLATES = [
    "I hear you on ${offer:.2f}, but I can't quite go that low. "
    "How about we meet at ${counter:.2f}? That's a real saving off our list price.",
    "I appreciate the offer of ${offer:.2f}! Here's the thing — my absolute best I can do "
    "is ${counter:.2f}. This {name} is worth every cent.",
    "${offer:.2f} is tough for me to work with. I can go to ${counter:.2f} — "
    "that's {discount:.1f}% off the list price. Deal?",
    "Let's be real — ${offer:.2f} doesn't cover our costs. "
    "But I want to make this happen. ${counter:.2f} — final step from my side.",
]

LOW_OFFER_REBUFF = [
    "Whoa, ${offer:.2f}? I respect the hustle, but that's well below what we can do. "
    "The {name} is genuinely worth ${list_price:.2f}. Come back with something more reasonable!",
    "Ha! I love the confidence at ${offer:.2f}. But seriously, that's not something "
    "we can entertain. The {name} costs us more than that. Try again?",
    "I wish I could do ${offer:.2f} — I really do. But that's not realistic for this product. "
    "What's a price you'd genuinely feel good about paying?",
]

RISING_TREND_ENCOURAGE = [
    "I can see you're moving in the right direction! Let's keep this going.",
    "Now we're getting somewhere! Getting closer to a deal.",
    "Good movement! I think we can find a number that works for both of us.",
]

ACCEPT_TEMPLATES = [
    "You know what — ${price:.2f} works for me! Let's get this {name} packed up for you. "
    "Great negotiating today! 🤝",
    "Deal at ${price:.2f}! Honestly, you drove a hard bargain. "
    "The {name} is going to serve you well. 🎉",
    "Sold at ${price:.2f}! You got a great price on the {name}. "
    "Pleasure doing business with you! ✅",
]

FINAL_OFFER_TEMPLATES = [
    "Alright, I'm going to be straight with you. My absolute final offer is ${counter:.2f}. "
    "I cannot go lower — this is genuinely the best I can do. Yes or no?",
    "Last card on the table: ${counter:.2f}. That's it from me. "
    "Take it and you'll be thrilled with the {name} — I promise.",
    "Final answer: ${counter:.2f}. I've given you everything I can. "
    "This is the best deal on the {name} you'll find anywhere.",
]

WALK_AWAY_TEMPLATES = [
    "I really tried, but we're too far apart. The {name} is priced fairly at ${floor:.2f} minimum, "
    "and I can't go lower. If you change your mind, come find me! 👋",
    "I've got to be honest — we're not going to reach a deal today. "
    "I respect your position, but I can't take less than ${floor:.2f} on the {name}. "
    "No hard feelings — hope to work with you another time!",
    "Looks like we've hit an impasse. The {name} is worth what it's worth, "
    "and below ${floor:.2f} just doesn't work for us. Best of luck to you! 🤝",
]

URGENCY_INSERTS = [
    "Just so you know — {urgency}",
    "Worth mentioning: {urgency}",
    "Quick heads up: {urgency}",
]


class NegotiationEngine:
    """
    Full negotiation session manager.
    Tracks state, runs strategy, and generates contextual responses.
    """

    def __init__(self, product: Product, buyer_profile: str = "new"):
        self.product = product
        self.strategy = PricingStrategy(product)
        self.ctx = NegotiationContext(
            product=product,
            buyer_profile=buyer_profile,
        )
        self.session_log: list[dict] = []
        self.deal_closed = False
        self.deal_price: Optional[float] = None
        self.walked_away = False
        self._agent_current_price = product.list_price

    # ── Public API ────────────────────────────────────────────────────────

    def open_negotiation(self) -> str:
        """Agent's opening line when buyer wants to negotiate."""
        templates = OPENER_TEMPLATES[self.strategy.style]
        text = random.choice(templates).format(
            name=self.product.name,
            list_price=self.product.list_price,
        )

        urgency = self.product.urgency_hint
        if urgency:
            insert = random.choice(URGENCY_INSERTS).format(urgency=urgency)
            text += f" ({insert})"

        self._log("agent", text)
        return text

    def receive_offer(self, buyer_offer: float) -> tuple[str, bool, bool]:
        """
        Process buyer's price offer.
        Returns: (agent_response_text, deal_closed, walked_away)
        """
        self.ctx.round_number += 1
        self.ctx.buyer_offer_history.append(buyer_offer)
        self._update_sentiment(buyer_offer)

        decision, agent_price, reason = self.strategy.evaluate_offer(self.ctx)

        response = self._generate_response(decision, buyer_offer, agent_price, reason)
        self._log("buyer", f"Offer: ${buyer_offer:.2f}")
        self._log("agent", response)

        if decision == AgentDecision.ACCEPT:
            self.deal_closed = True
            self.deal_price = buyer_offer
        elif decision == AgentDecision.WALK_AWAY:
            self.walked_away = True
        elif decision in (AgentDecision.COUNTER, AgentDecision.FINAL_OFFER):
            self._agent_current_price = agent_price
            # Update concession fatigue
            self.ctx.concession_fatigue = (
                (self.product.list_price - agent_price) / self.product.list_price
            )

        return response, self.deal_closed, self.walked_away

    def get_session_summary(self) -> dict:
        """Returns a summary of the negotiation session."""
        return {
            "product": self.product.name,
            "list_price": self.product.list_price,
            "floor_price": self.product.floor_price,
            "rounds": self.ctx.round_number,
            "buyer_offers": self.ctx.buyer_offer_history,
            "deal_closed": self.deal_closed,
            "deal_price": self.deal_price,
            "savings": (
                round(self.product.list_price - self.deal_price, 2)
                if self.deal_price else None
            ),
            "savings_pct": (
                round(
                    (self.product.list_price - self.deal_price)
                    / self.product.list_price * 100, 1
                )
                if self.deal_price else None
            ),
            "agent_style": self.strategy.get_style_label(),
        }

    # ── Private Helpers ───────────────────────────────────────────────────

    def _generate_response(
        self,
        decision: AgentDecision,
        offer: float,
        agent_price: float,
        reason: str,
    ) -> str:
        p = self.product
        discount_pct = (p.list_price - agent_price) / p.list_price * 100

        if decision == AgentDecision.ACCEPT:
            text = random.choice(ACCEPT_TEMPLATES).format(
                price=offer, name=p.name
            )

        elif decision == AgentDecision.WALK_AWAY:
            if reason == "offer_insultingly_low":
                text = random.choice(LOW_OFFER_REBUFF).format(
                    offer=offer, name=p.name, list_price=p.list_price
                )
            else:
                text = random.choice(WALK_AWAY_TEMPLATES).format(
                    name=p.name, floor=agent_price
                )

        elif decision == AgentDecision.FINAL_OFFER:
            text = random.choice(FINAL_OFFER_TEMPLATES).format(
                counter=agent_price, name=p.name
            )

        else:  # COUNTER
            text = random.choice(COUNTER_TEMPLATES).format(
                offer=offer,
                counter=agent_price,
                name=p.name,
                discount=discount_pct,
            )
            # Add encouragement if buyer is trending up
            if self.ctx.buyer_trend == "rising" and self.ctx.round_number > 1:
                text = random.choice(RISING_TREND_ENCOURAGE) + " " + text

        # Sprinkle urgency hints occasionally
        urgency = p.urgency_hint
        if urgency and random.random() < 0.35 and decision == AgentDecision.COUNTER:
            text += f" (P.S. — {urgency})"

        return text

    def _update_sentiment(self, offer: float):
        """Crude sentiment update based on offer quality."""
        offer_ratio = offer / self.product.list_price
        if offer_ratio >= 0.9:
            self.ctx.buyer_sentiment = min(1.0, self.ctx.buyer_sentiment + 0.15)
        elif offer_ratio >= 0.75:
            self.ctx.buyer_sentiment = min(1.0, self.ctx.buyer_sentiment + 0.05)
        elif offer_ratio < 0.5:
            self.ctx.buyer_sentiment = max(0.0, self.ctx.buyer_sentiment - 0.2)

        # Trend boost
        if self.ctx.buyer_trend == "rising":
            self.ctx.buyer_sentiment = min(1.0, self.ctx.buyer_sentiment + 0.1)

    def _log(self, speaker: str, text: str):
        self.session_log.append({"speaker": speaker, "text": text})
