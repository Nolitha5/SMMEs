# 🤝 SmartDeal — AI Price Negotiation Agent

An intelligent e-commerce price negotiation agent that **thinks like a seasoned salesperson**.  
No LLM API key needed — the reasoning engine is fully self-contained.

---

## ✨ What Makes It Unique

Unlike simple "fixed discount" bots, SmartDeal uses a **multi-factor negotiation brain**:

| Feature | Description |
|---|---|
| 🧠 Strategy Engine | 3 seller modes: Firm / Flexible / Eager (set by demand + stock) |
| 📈 Sigmoid Concession Curve | Early rounds = bigger drops. Late rounds = tiny steps (tightening squeeze) |
| 🔁 Buyer Trend Detection | Detects if offers are rising, falling, or stalled — and responds accordingly |
| 😊 Sentiment Tracking | Low-ball offers lower trust; rising offers build rapport |
| 👤 Buyer Profiles | New / Loyal / VIP buyers get different floor prices |
| ⚡ Scarcity & Demand Signals | Low-stock + high-demand items resist discounts and use urgency messaging |
| 🚶 Walk-Away Logic | Agent refuses insultingly low offers and walks away from stalled negotiations |
| 💬 Dynamic Dialogue | Context-aware responses that acknowledge buyer trends and urgency |

---

## 🚀 Quick Start

```bash
pip install rich
python main.py          # Interactive mode
python demo.py          # Auto-demo (no input needed)
```

---

## 📁 Project Structure

```
smartdeal/
├── main.py                    # Interactive entry point
├── demo.py                    # Auto-demo scenarios
├── requirements.txt
├── core/
│   ├── product.py             # Product catalog & data model
│   ├── pricing_strategy.py    # Negotiation decision engine
│   └── negotiation_engine.py  # Dialogue generation & session state
└── ui/
    └── terminal.py            # Rich terminal UI
```

---

## 🎮 How to Negotiate

1. Run `python main.py`
2. Browse the product catalog
3. Pick a product ID (e.g. `LP001`)
4. Select your buyer profile (`new` / `loyal` / `vip`)
5. Make offers — the AI will counter, accept, or walk away

**Tips:**
- Don't low-ball — Alex will call you out!
- Make incremental offers — the agent rewards rising bids
- VIP profile = slightly lower floor price
- Stall too long = Alex walks away

---

## 🧩 Extending the Agent

- **Add products**: Edit `core/product.py` → `CATALOG`
- **Tune strategy**: Edit `core/pricing_strategy.py` → `PricingStrategy`
- **Add LLM responses**: Replace template selection in `negotiation_engine.py` with an API call to Claude/GPT
- **Add a web UI**: Wrap `NegotiationEngine` in a FastAPI app with WebSocket for real-time chat
